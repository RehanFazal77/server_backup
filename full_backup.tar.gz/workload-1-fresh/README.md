# Workload 1 Repository
This repository contains workload configurations for Nephio.
