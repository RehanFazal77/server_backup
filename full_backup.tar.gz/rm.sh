#!/bin/bash

# Advanced cleanup script that removes finalizers if resources are stuck
set -e

echo "Starting advanced cleanup of smo-cluster1 resources..."

# List of resources to clean up in dependency order
RESOURCES=(
    "machine smo-cluster1-control-plane-0"
    "metal3machine smo-cluster1-control-plane-0" 
    "kubeadmcontrolplane smo-cluster1-control-plane"
    "metal3machinetemplate smo-cluster1-control-plane-template"
    "metal3cluster smo-cluster1"
    "cluster smo-cluster1"
)

# First attempt normal deletion
for resource in "${RESOURCES[@]}"; do
    read -r kind name <<< "$resource"
    echo "Attempting to delete $kind $name..."
    kubectl delete $kind $name -n default --force --grace-period=0 --wait=false 2>/dev/null || true
done

echo "Waiting a moment for deletions to process..."
sleep 10

# Check for stuck resources and remove finalizers
for resource in "${RESOURCES[@]}"; do
    read -r kind name <<< "$resource"
    
    if kubectl get $kind $name -n default --no-headers 2>/dev/null; then
        echo "Resource $kind/$name is stuck. Removing finalizers..."
        kubectl patch $kind $name -n default --type=merge -p '{"metadata":{"finalizers":[]}}' 2>/dev/null || true
        
        # Try deletion again after removing finalizers
        kubectl delete $kind $name -n default --force --grace-period=0 2>/dev/null || true
    fi
done

# Final verification
echo "Verification - remaining smo-cluster1 resources:"
for resource in cluster metal3cluster metal3machinetemplate kubeadmcontrolplane metal3machine machine; do
    if kubectl get $resource -n default 2>/dev/null | grep -q smo-cluster1; then
        echo "WARNING: Still found $resource resources"
        kubectl get $resource -n default | grep smo-cluster1
    fi
done

echo "Cleanup completed!"
