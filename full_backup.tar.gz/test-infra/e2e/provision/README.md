# Quick Start for GCE and VMs running in other environments

Moved to the docs repository:

* [Install
  Guide](https://github.com/nephio-project/docs/blob/main/content/en/docs/guides/install-guides/_index.md)
* [Free5GC exercise](https://github.com/nephio-project/docs/blob/main/content/en/docs/guides/user-guides/exercise-1-free5gc.md)
* [OAI exercise](https://github.com/nephio-project/docs/blob/main/content/en/docs/guides/user-guides/exercise-2-oai.md)
