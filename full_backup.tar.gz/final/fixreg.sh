#!/bin/bash
# register-workload-cluster.sh — Minimal version matching existing clusters

echo "🔗 Registering Workload Cluster with Management Cluster..."

# Step 1: Create secret for workload cluster kubeconfig
kubectl create secret generic workload-cluster-kubeconfig \
  --from-file=value=/tmp/workload-kubeconfig \
  --namespace=default \
  --dry-run=client -o yaml | kubectl apply -f -

echo "✅ Secret created for workload cluster."

# Step 2: Register the workload cluster (Cluster API object)
kubectl apply -f - <<EOF
apiVersion: cluster.x-k8s.io/v1beta1
kind: Cluster
metadata:
  name: workload-cluster-1
  namespace: default
  annotations:
    nephio.org/kubeconfig-secret: "workload-cluster-kubeconfig"
  labels:
    nephio.org/cluster: workload-cluster-1
    nephio.org/purpose: testing
    nephio.org/environment: development
spec:
  controlPlaneRef:
    apiVersion: controlplane.cluster.x-k8s.io/v1beta1
    kind: KubeadmControlPlane
    name: workload-cluster-1-control-plane
  infrastructureRef:
    apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
    kind: Metal3Cluster
    name: workload-cluster-1
EOF

echo "✅ Workload cluster registered successfully!"
kubectl get cluster workload-cluster-1

