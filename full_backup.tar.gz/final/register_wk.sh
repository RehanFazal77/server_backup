#!/bin/bash
# register-workload-cluster.sh

echo "🔗 Registering Workload Cluster with Management Cluster..."

# Create secret with workload cluster kubeconfig
kubectl create secret generic workload-cluster-kubeconfig \
  --from-file=value=/tmp/workload-kubeconfig \
  --dry-run=client -o yaml | kubectl apply -f -

# Register the workload cluster
kubectl apply -f - <<EOF
apiVersion: cluster.x-k8s.io/v1beta1
kind: Cluster
metadata:
  name: workload-cluster-1
  namespace: default
  labels:
    nephio.org/cluster: workload-cluster-1
    nephio.org/purpose: testing
    nephio.org/environment: development
spec:
  description: "Workload Cluster for Exercise 1 Testing"
  kubeconfig:
    secretRef:
      name: workload-cluster-kubeconfig
EOF

echo "✅ Workload cluster registered!"
kubectl get clusters.nephio.org
