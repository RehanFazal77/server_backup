#!/bin/bash

# --- Script to Install Kubeadm Cluster v1.29.0 with Containerd and Calico ---

K8S_VERSION="1.29.0"
POD_CIDR="192.168.0.0/16" # Default for Calico, ensure it doesn't clash
CRI_SOCKET="unix:///var/run/containerd/containerd.sock"
CALICO_MANIFEST="https://raw.githubusercontent.com/projectcalico/calico/v3.26.1/manifests/calico.yaml" # Check compatibility

echo "🚀 Starting Kubernetes v${K8S_VERSION} installation..."

# --- Basic Prerequisites ---
echo "Checking prerequisites..."
# Disable Swap
echo "  Disabling swap..."
sudo swapoff -a
# Keep swap off after reboot
sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

# Ensure containerd is running (assuming it's installed)
echo "  Ensuring containerd is active..."
sudo systemctl enable --now containerd

# Ensure kubeadm, kubelet, kubectl are installed for the target version
# (Add installation/update steps here if needed, e.g., using apt)
# Example for Debian/Ubuntu (uncomment and adapt if needed):
# echo "  Ensuring K8s packages (kubeadm, kubelet, kubectl)..."
# sudo apt-get update
# sudo apt-get install -y apt-transport-https ca-certificates curl gpg
# curl -fsSL https://pkgs.k8s.io/core:/stable:/v${K8S_VERSION%.*}/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
# echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v${K8S_VERSION%.*}/deb/ /" | sudo tee /etc/apt/sources.list.d/kubernetes.list
# sudo apt-get update
# KUBE_PKG_VERSION=$(apt-cache madison kubeadm | grep ${K8S_VERSION} | head -1 | awk '{print $3}') # Find specific package version
# if [ -z "$KUBE_PKG_VERSION" ]; then echo "Error: K8s version ${K8S_VERSION} packages not found."; exit 1; fi
# sudo apt-get install -y kubelet="$KUBE_PKG_VERSION" kubeadm="$KUBE_PKG_VERSION" kubectl="$KUBE_PKG_VERSION"
# sudo apt-mark hold kubelet kubeadm kubectl

echo "✅ Prerequisites seem okay."

# --- Initialize Control Plane ---
echo "🛠️ Initializing control plane with Kubeadm..."
sudo kubeadm init \
  --kubernetes-version "${K8S_VERSION}" \
  --pod-network-cidr="${POD_CIDR}" \
  --cri-socket="${CRI_SOCKET}"

# Check if init was successful
if [ $? -ne 0 ]; then
  echo "❌ Kubeadm init failed. Please check the errors above."
  exit 1
fi

echo "🔑 Setting up Kubeconfig for user $(whoami)..."
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

echo "🔌 Installing Calico CNI..."
kubectl apply -f "${CALICO_MANIFEST}"

# Check if CNI application was successful
if [ $? -ne 0 ]; then
  echo "⚠️ Failed to apply Calico manifest. The cluster might not function correctly."
  echo "You might need to manually apply it: kubectl apply -f ${CALICO_MANIFEST}"
fi

echo "🎉 Cluster installation initiated!"
echo "⏳ Wait a few minutes for the node to become Ready and Calico pods to start."
echo "Check status with: kubectl get nodes"
echo "Check Calico pods with: kubectl get pods -n calico-system"
