#!/bin/bash

# One-shot Kubernetes leftover cleanup
# Kills processes, frees ports, clears containers and CNI

set -e

echo "=========================================="
echo "Kubernetes Leftover Cleanup Script"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

echo "[1/5] Killing leftover Kubernetes processes..."
pkill -f kubelet || true
pkill -f etcd || true
pkill -f kube-apiserver || true
pkill -f kube-controller-manager || true
pkill -f kube-scheduler || true
pkill -f containerd || true
pkill -f docker || true

echo "[2/5] Freeing Kubernetes ports..."
fuser -k 6443/tcp 10257/tcp 10259/tcp 2379/tcp 2380/tcp || true

echo "[3/5] Removing leftover containers/images (if Docker installed)..."
if command -v docker &> /dev/null; then
    docker rm -f $(docker ps -aq) || true
    docker system prune -af || true
fi

echo "[4/5] Removing leftover CNI directories..."
rm -rf /etc/cni/net.d /opt/cni || true

echo "[5/5] Flushing iptables and IPVS rules..."
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X
if command -v ipvsadm &> /dev/null; then
    ipvsadm --clear
fi

echo ""
echo "=========================================="
echo "Cleanup Complete!"
echo "All leftover Kubernetes processes, ports, containers, and network rules are cleared."
echo "RAM usage should now return to normal."

