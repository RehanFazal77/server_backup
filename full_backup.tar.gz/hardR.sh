#!/bin/bash

# Complete Kubernetes Cluster Cleanup Script
# Works even if kubectl, containerd, or Docker are gone

set -e

echo "=========================================="
echo "Kubernetes Full Cleanup Script"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Function to safely stop and disable a systemd service
stop_disable_service() {
    if systemctl list-unit-files | grep -q "^$1"; then
        echo "Stopping and disabling $1..."
        systemctl stop $1 || true
        systemctl disable $1 || true
    fi
}

echo "[1/10] Resetting Kubernetes cluster..."
if command -v kubeadm &> /dev/null; then
    kubeadm reset -f || true
else
    echo "kubeadm not found, skipping cluster reset"
fi

echo "[2/10] Removing kubeconfig for root and users..."
rm -f /etc/kubernetes/admin.conf
rm -rf $HOME/.kube
if [ -n "$SUDO_USER" ]; then
    rm -rf /home/$SUDO_USER/.kube
fi

echo "[3/10] Removing Kubernetes packages..."
apt-mark unhold kubeadm kubelet kubectl || true
apt-get purge -y kubeadm kubelet kubectl || true
apt-get autoremove -y
rm -rf /etc/apt/keyrings/kubernetes-apt-keyring.gpg
rm -rf /etc/apt/sources.list.d/kubernetes.list

echo "[4/10] Removing containerd..."
stop_disable_service containerd
apt-get purge -y containerd || true
apt-get autoremove -y
rm -rf /etc/containerd /var/lib/containerd

echo "[5/10] Removing Docker..."
stop_disable_service docker
apt-get purge -y docker-ce docker-ce-cli docker-buildx-plugin docker-compose-plugin || true
apt-get autoremove -y
rm -rf /var/lib/docker /var/lib/containerd /etc/docker /etc/apt/keyrings/docker.gpg /etc/apt/sources.list.d/docker.list

echo "[6/10] Removing CNI plugins..."
rm -rf /etc/cni/net.d
rm -rf /opt/cni

echo "[7/10] Removing leftover Kubernetes directories..."
rm -rf /etc/kubernetes
rm -rf /var/lib/kubelet
rm -rf /var/lib/etcd
rm -rf /etc/rancher/local-path-provisioner

echo "[8/10] Resetting sysctl and kernel modules..."
rm -f /etc/modules-load.d/k8s.conf
rm -f /etc/sysctl.d/k8s.conf
sysctl --system || true
modprobe -r overlay || true
modprobe -r br_netfilter || true

echo "[9/10] Re-enabling swap..."
sed -i 's/^#\(.* swap .*\)$/\1/' /etc/fstab
swapon -a || true

echo "[10/10] Flushing iptables and IPVS rules..."
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X
if command -v ipvsadm &> /dev/null; then
    ipvsadm --clear
fi

echo ""
echo "=========================================="
echo "Full Cleanup Complete!"
echo "=========================================="
echo "System is now free from Kubernetes, Docker, containerd, Calico, local-path storage, CNI, and network rules."

