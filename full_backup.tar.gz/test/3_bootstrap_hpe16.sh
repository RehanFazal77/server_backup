#!/bin/bash
set -e

# --- Configuration ---
CLUSTER_NAME="hpe16-cluster"
BMH_NAME="hpe16-bmh"
TARGET_IP="10.200.105.57"
SSH_USER="rehanfazal"
# ---

echo "--- 🚀 Starting cluster bootstrap for ${CLUSTER_NAME} ---"

# Wait for BMH Association
echo "1. Waiting for BMH association..."
MACHINE_NAME=""
while [ -z "$MACHINE_NAME" ]; do
  MACHINE_NAME=$(kubectl get bmh "$BMH_NAME" -n default -o jsonpath='{.spec.consumerRef.name}' 2>/dev/null || true)
  [ -z "$MACHINE_NAME" ] && sleep 5 && printf "."
done
echo -e "\n✅ BMH associated: ${MACHINE_NAME}"

# Wait for Bootstrap Secret
echo "2. Waiting for bootstrap secret..."
BOOTSTRAP_READY=""
while [ "$BOOTSTRAP_READY" != "true" ]; do
  BOOTSTRAP_READY=$(kubectl get machine "$MACHINE_NAME" -n default -o jsonpath='{.status.bootstrapReady}' 2>/dev/null || true)
  [ "$BOOTSTRAP_READY" != "true" ] && sleep 5 && printf "."
done
echo -e "\n✅ Bootstrap secret ready"

# Extract SSH Key
echo "3. Extracting SSH key..."
kubectl get secret "${CLUSTER_NAME}-ssh-key" -n default -o jsonpath='{.stringData.value}' > "/tmp/${CLUSTER_NAME}_ssh_key"
chmod 600 "/tmp/${CLUSTER_NAME}_ssh_key"

# Create kubeadm config
echo "4. Creating kubeadm config..."
cat > "/tmp/${CLUSTER_NAME}-kubeadm.yaml" <<EOF
---
apiVersion: kubeadm.k8s.io/v1beta3
kind: ClusterConfiguration
clusterName: ${CLUSTER_NAME}
controlPlaneEndpoint: ${TARGET_IP}:6443
kubernetesVersion: v1.29.0
networking:
  podSubnet: 192.168.0.0/16
  serviceSubnet: 10.96.0.0/16
---
apiVersion: kubeadm.k8s.io/v1beta3
kind: InitConfiguration
nodeRegistration:
  imagePullPolicy: IfNotPresent
  kubeletExtraArgs: {}
EOF

# Bootstrap cluster
echo "5. Bootstrapping Kubernetes cluster..."
cat "/tmp/${CLUSTER_NAME}-kubeadm.yaml" | ssh -i "/tmp/${CLUSTER_NAME}_ssh_key" -o "StrictHostKeyChecking=no" "${SSH_USER}@${TARGET_IP}" "sudo tee /tmp/kubeadm.yaml > /dev/null"

BOOTSTRAP_CMDS=$(cat <<EOF
set -e
echo "  Running kubeadm init..."
sudo kubeadm init --config /tmp/kubeadm.yaml --ignore-preflight-errors=all

echo "  Setting up kubeconfig..."
mkdir -p \$HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf \$HOME/.kube/config
sudo chown \$(id -u):\$(id -g) \$HOME/.kube/config

echo "  Installing Calico CNI..."
kubectl apply -f https://raw.githubusercontent.com/projectcalico/calico/v3.26.1/manifests/calico.yaml

echo "  Waiting for node readiness..."
until kubectl get nodes -o jsonpath='{.items[0].status.conditions[?(@.type=="Ready")].status}' | grep -q "True"; do
  sleep 5
  printf "."
done

NODE_NAME=\$(kubectl get nodes -o jsonpath='{.items[0].metadata.name}')
echo -e "\n  Node \$NODE_NAME is Ready"

echo "  Patching providerID..."
kubectl patch node \$NODE_NAME -p '{"spec":{"providerID":"metal3://default/${BMH_NAME}"}}'

echo "  ✅ Cluster bootstrap complete!"
EOF
)

ssh -i "/tmp/${CLUSTER_NAME}_ssh_key" -o "StrictHostKeyChecking=no" "${SSH_USER}@${TARGET_IP}" "$BOOTSTRAP_CMDS"

# Cleanup
rm "/tmp/${CLUSTER_NAME}_ssh_key" "/tmp/${CLUSTER_NAME}-kubeadm.yaml"

echo "---
🎉 Bootstrap complete! Check cluster status with:"
echo "kubectl get machine -n default"
echo "kubectl get bmh -n default"
