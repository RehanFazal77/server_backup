#!/bin/bash
set -e

# --- Configuration ---
TARGET_IP="10.200.105.57"
SSH_USER="rehanfazal"
SSH_KEY_PATH="/home/rehanfazal/.ssh/id_rsa"
K8S_VERSION="1.29.0"
# ---

echo "🚀 Starting remote prerequisite installation on ${TARGET_IP}..."

# Test SSH connection
echo "Testing SSH connection..."
ssh -i "$SSH_KEY_PATH" -o "StrictHostKeyChecking=no" "${SSH_USER}@${TARGET_IP}" "echo '✅ SSH connection successful'"

# Remote installation script using official Kubernetes repo
REMOTE_SCRIPT=$(cat <<'EOF'
#!/bin/bash
set -e

echo "📦 Starting prerequisite installation..."

K8S_VERSION="1.29.0"

echo "  Disabling swap..."
sudo swapoff -a
sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

echo "📦 Installing containerd..."
sudo apt-get update
sudo apt-get install -y containerd

echo "🔧 Configuring containerd..."
sudo mkdir -p /etc/containerd
sudo containerd config default | sudo tee /etc/containerd/config.toml >/dev/null
sudo sed -i 's/SystemdCgroup = false/SystemdCgroup = true/g' /etc/containerd/config.toml

echo "🔄 Restarting and enabling containerd..."
sudo systemctl restart containerd
sudo systemctl enable containerd

echo "📦 Setting up Kubernetes repository using official sources..."

# Install prerequisites
sudo apt-get install -y apt-transport-https ca-certificates curl

# Add Kubernetes official signing key
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.29/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg

# Add Kubernetes repository
echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.29/deb/ /" | sudo tee /etc/apt/sources.list.d/kubernetes.list

sudo apt-get update

echo "  Installing Kubernetes v${K8S_VERSION}..."

# First, check available versions
echo "Available Kubernetes packages:"
apt-cache policy kubeadm kubelet kubectl | grep -E '(Candidate|Version table)' -A 2

# Try to install specific version
if sudo apt-get install -y kubelet=${K8S_VERSION}* kubeadm=${K8S_VERSION}* kubectl=${K8S_VERSION}*; then
    echo "✅ Successfully installed Kubernetes v${K8S_VERSION}"
else
    echo "⚠️  Could not install exact version, trying latest in 1.29 series"
    sudo apt-get install -y kubelet kubeadm kubectl
    echo "Installed version:"
    kubeadm version --short 2>/dev/null || echo "Could not determine version"
fi

echo "🔒 Holding Kubernetes packages..."
sudo apt-mark hold kubelet kubeadm kubectl

echo "✅ Kubernetes installation completed!"
EOF
)

echo "Executing installation on ${TARGET_IP}..."
ssh -i "$SSH_KEY_PATH" -o "StrictHostKeyChecking=no" "${SSH_USER}@${TARGET_IP}" "bash -s" <<< "$REMOTE_SCRIPT"

echo "🎉 Prerequisites completed on ${TARGET_IP}!"
