apiVersion: v1
kind: Secret
metadata:
  # Secret for BMC credentials (referenced by BMH, can be dummy if BMC isn't used)
  name: hpe16-bmc-credentials
  namespace: default
type: Opaque
stringData:
  username: dummy
  password: dummy

---
apiVersion: metal3.io/v1alpha1
kind: BareMetalHost
metadata:
  name: hpe16-bmh
  namespace: default
  labels:
    # Label to help the Metal3MachineTemplate select this host
    cluster.x-k8s.io/cluster-name: hpe16-cluster
spec:
  online: true
  # Tells Metal3/CAPI the OS and K8s are already running
  externallyProvisioned: true
  # The MAC address CAPI will use to identify the node
  bootMACAddress: "3c:fd:fe:ef:10:4c"
  bmc:
    # Address and credentials are required but ignored for externallyProvisioned
    address: "ipmi://0.0.0.0"
    credentialsName: "hpe16-bmc-credentials"

---
apiVersion: cluster.x-k8s.io/v1beta1
kind: Cluster
metadata:
  name: hpe16-cluster
  namespace: default
  annotations:
    # Tells CAPI controllers to skip TLS verification when connecting
    cluster.x-k8s.io/kubeconfig-insecure: "true"
spec:
  # The endpoint CAPI controllers will use to connect
  controlPlaneEndpoint:
    host: "10.200.105.57"
    port: 6443
  # Reference to the control plane provider (KubeadmControlPlane)
  controlPlaneRef:
    apiVersion: controlplane.cluster.x-k8s.io/v1beta1
    kind: KubeadmControlPlane
    name: hpe16-control-plane
  # Reference to the infrastructure provider (Metal3Cluster)
  infrastructureRef:
    apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
    kind: Metal3Cluster
    name: hpe16-cluster

---
apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
kind: Metal3Cluster
metadata:
  name: hpe16-cluster
  namespace: default
spec:
  # Endpoint matches the Cluster spec, defines where the cluster API lives
  controlPlaneEndpoint:
    host: "10.200.105.57"
    port: 6443
  # No bundle URL needed as we skip TLS verification

---
apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
kind: Metal3MachineTemplate
metadata:
  name: hpe16-control-plane-template
  namespace: default
spec:
  template:
    spec:
      # Image is ignored for externally provisioned but required by schema
      image:
        url: ""
        checksum: ""
      # Selects the BMH based on the label we added
      hostSelector:
        matchLabels:
          cluster.x-k8s.io/cluster-name: hpe16-cluster

---
apiVersion: controlplane.cluster.x-k8s.io/v1beta1
kind: KubeadmControlPlane
metadata:
  name: hpe16-control-plane
  namespace: default
  annotations:
    # CRITICAL: Also apply the insecure flag here for the KCP controller
    cluster.x-k8s.io/kubeconfig-insecure: "true"
spec:
  replicas: 1
  version: "v1.29.0" # Match the K8s version running on nearrtic
  # Reference to the infrastructure template (Metal3MachineTemplate)
  machineTemplate:
    infrastructureRef:
      apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
      kind: Metal3MachineTemplate
      name: hpe16-control-plane-template
  # Kubeadm config details CAPI uses to understand the node
  kubeadmConfigSpec:
    initConfiguration:
      nodeRegistration:
        kubeletExtraArgs:
          # Tells Kubelet its provider ID, essential for CAPI matching
          provider-id: metal3://{{ ds.meta_data.uuid }} # This template gets rendered
    # No JoinConfiguration needed for externally provisioned single-node control plane
    # No ClusterConfiguration needed unless customizing API server/etcd etc.
    # No files/users needed as the node is already running
