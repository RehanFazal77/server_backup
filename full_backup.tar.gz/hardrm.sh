#!/bin/bash

# --- Script to Remove Kubeadm Cluster ---

echo "🛑 WARNING: This script will completely remove the Kubernetes cluster!"
read -p "Are you sure you want to continue? (y/N): " confirm
if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
  echo "Aborting."
  exit 1
fi

echo "🚀 Resetting Kubeadm..."
# Force reset, ignore errors if already partially reset, specify CRI socket
sudo kubeadm reset -f --ignore-preflight-errors=all --cri-socket=unix:///var/run/containerd/containerd.sock || true

echo "🧹 Cleaning up directories..."
sudo rm -rf /etc/cni/net.d
sudo rm -rf /etc/kubernetes/
sudo rm -rf /var/lib/etcd/
# Remove user's kubeconfig too
rm -rf $HOME/.kube/config

echo "🔥 Flushing IPtables..."
sudo iptables -F && sudo iptables -t nat -F && sudo iptables -t mangle -F && sudo iptables -X || true

echo "🔄 Restarting Containerd..."
sudo systemctl restart containerd

echo "✅ Cluster removal complete."
echo "You may need to manually remove Kubeadm/Kubelet/Kubectl packages if desired."
